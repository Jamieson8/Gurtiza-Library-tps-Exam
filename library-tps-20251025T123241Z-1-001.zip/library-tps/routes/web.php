<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BookController;
use App\Http\Controllers\MemberController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Main wall (dashboard)
Route::get('/', function () {
    return view('dashboard'); // 👈 this will load resources/views/dashboard.blade.php
});

// Members
Route::resource('members', MemberController::class);
Route::get('members/{member}/books', [MemberController::class, 'borrowedBooks'])
    ->name('members.books');

// Books
Route::resource('books', BookController::class);
