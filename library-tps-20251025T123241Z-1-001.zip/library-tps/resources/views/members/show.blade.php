@extends('layouts.app')

@section('content')
<h1>{{ $member->full_name }}</h1>

<ul>
    <li><strong>Email:</strong> {{ $member->email }}</li>
    <li><strong>Contact Number:</strong> {{ $member->contact_number ?? 'N/A' }}</li>
</ul>

@if($member->books->count())
    <h3>Borrowed Books:</h3>
    <ul>
        @foreach($member->books as $book)
            <li>{{ $book->title }} by {{ $book->author }}</li>
        @endforeach
    </ul>
@else
    <p>No borrowed books.</p>
@endif

<a href="{{ route('members.index') }}" class="btn btn-secondary">Back</a>
@endsection
