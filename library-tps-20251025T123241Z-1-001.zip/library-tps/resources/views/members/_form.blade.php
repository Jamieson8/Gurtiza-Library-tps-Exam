@csrf

<div class="mb-3">
    <label class="form-label">First Name</label>
    <input type="text" name="first_name" value="{{ old('first_name', $member->first_name ?? '') }}" class="form-control" required>
    @error('first_name') <small class="text-danger">{{ $message }}</small> @enderror
</div>

<div class="mb-3">
    <label class="form-label">Last Name</label>
    <input type="text" name="last_name" value="{{ old('last_name', $member->last_name ?? '') }}" class="form-control" required>
    @error('last_name') <small class="text-danger">{{ $message }}</small> @enderror
</div>

<div class="mb-3">
    <label class="form-label">Email</label>
    <input type="email" name="email" value="{{ old('email', $member->email ?? '') }}" class="form-control" required>
    @error('email') <small class="text-danger">{{ $message }}</small> @enderror
</div>

<div class="mb-3">
    <label class="form-label">Contact Number</label>
    <input type="text" name="contact_number" value="{{ old('contact_number', $member->contact_number ?? '') }}" class="form-control">
</div>

<button class="btn btn-success">Save</button>
<a href="{{ route('members.index') }}" class="btn btn-secondary">Cancel</a>
