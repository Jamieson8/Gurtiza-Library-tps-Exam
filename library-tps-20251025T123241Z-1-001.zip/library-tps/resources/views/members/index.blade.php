@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card shadow-sm">
                <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <!-- Back to Main Wall Button -->
                        <a href="{{ url('/') }}" class="btn btn-outline-light me-3">
                            <i class="fas fa-arrow-left"></i> Back to Main
                        </a>
                        <h4 class="mb-0"><i class="fas fa-users"></i> Members List</h4>
                    </div>
                    <a href="{{ route('members.create') }}" class="btn btn-success">
                        <i class="fas fa-user-plus"></i> Add Member
                    </a>
                </div>

                <div class="card-body">
                    <!-- Search & Filter -->
                    <form method="GET" action="{{ route('members.index') }}" class="row g-2 mb-3">
                        <div class="col-md-4">
                            <input type="text" name="search" class="form-control"
                                   placeholder="Search by name or email"
                                   value="{{ $search ?? '' }}">
                        </div>
                        <div class="col-md-3">
                            <select name="status" class="form-select">
                                <option value="">-- All Members --</option>
                                <option value="borrowers" {{ $status == 'borrowers' ? 'selected' : '' }}>Borrowers</option>
                                <option value="non-borrowers" {{ $status == 'non-borrowers' ? 'selected' : '' }}>Non-Borrowers</option>
                            </select>
                        </div>
                        <div class="col-md-5 d-flex">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-search"></i> Search
                            </button>
                            <a href="{{ route('members.index') }}" class="btn btn-secondary">
                                <i class="fas fa-sync"></i> Reset
                            </a>
                        </div>
                    </form>

                    <!-- Table -->
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead class="table-dark">
                                <tr>
                                    <th>#</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Contact Number</th>
                                    <th>Borrowed Books</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($members as $member)
                                    <tr>
                                        <td>{{ $member->id }}</td>
                                        <td>{{ $member->first_name }}</td>
                                        <td>{{ $member->last_name }}</td>
                                        <td>{{ $member->email }}</td>
                                        <td>{{ $member->contact_number }}</td>
                                        <td>
                                            @if($member->books->count() > 0)
                                                <a href="{{ route('members.books', $member->id) }}" class="badge bg-info text-decoration-none">
                                                    {{ $member->books->count() }} borrowed
                                                </a>
                                            @else
                                                <span class="badge bg-secondary">None</span>
                                            @endif
                                        </td>
                                        <td>
                                            <a href="{{ route('members.edit', $member->id) }}" class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                            <form action="{{ route('members.destroy', $member->id) }}" method="POST" class="d-inline">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="7" class="text-center text-muted">No members found.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="mt-3">
                        {{ $members->appends(['search' => $search, 'status' => $status])->links() }}
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
@endsection
