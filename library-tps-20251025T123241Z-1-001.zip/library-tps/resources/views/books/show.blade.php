@extends('layouts.app')

@section('content')
<h1>{{ $book->title }}</h1>

<ul>
    <li><strong>Author:</strong> {{ $book->author }}</li>
    <li><strong>ISBN:</strong> {{ $book->isbn ?? 'N/A' }}</li>
    <li><strong>Published Year:</strong> {{ $book->published_year ?? 'N/A' }}</li>
    <li><strong>Status:</strong> 
        {{ $book->borrower ? 'Borrowed by '.$book->borrower->full_name : 'Available' }}
    </li>
</ul>

<a href="{{ route('books.index') }}" class="btn btn-secondary">Back</a>
@endsection
