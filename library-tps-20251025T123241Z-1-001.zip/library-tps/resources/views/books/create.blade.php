@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card shadow-sm">
                <div class="card-header bg-success text-white">
                    <h4 class="mb-0"><i class="fas fa-book"></i> Add New Book</h4>
                </div>
                <div class="card-body">

                    <!-- Validation Errors -->
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form action="{{ route('books.store') }}" method="POST">
                        @csrf

                        <div class="mb-3">
                            <label for="title" class="form-label">Book Title</label>
                            <input type="text" name="title" class="form-control" value="{{ old('title') }}" required>
                        </div>

                        <div class="mb-3">
                            <label for="author" class="form-label">Author</label>
                            <input type="text" name="author" class="form-control" value="{{ old('author') }}" required>
                        </div>

                        <!-- Borrower Dropdown -->
                        <div class="mb-3">
                            <label for="borrower_id" class="form-label">Borrower</label>
                            <div class="d-flex">
                                <select name="borrower_id" id="borrower_id" class="form-control">
                                    <option value="">-- Available (No Borrower) --</option>
                                    @foreach($members as $member)
                                        <option value="{{ $member->id }}"
                                            {{ old('borrower_id') == $member->id ? 'selected' : '' }}>
                                            {{ $member->first_name }} {{ $member->last_name }}
                                        </option>
                                    @endforeach
                                </select>
                                <a href="{{ route('members.create') }}" class="btn btn-success ms-2" title="Register New Borrower">
                                    <i class="fas fa-user-plus"></i>
                                </a>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end">
                            <a href="{{ route('books.index') }}" class="btn btn-outline-secondary me-2">
                                <i class="fas fa-times"></i> Cancel
                            </a>
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-save"></i> Save Book
                            </button>
                        </div>
                    </form>

                </div>
            </div>

        </div>
    </div>
</div>
@endsection
