@csrf

<div class="mb-3">
    <label class="form-label">Title</label>
    <input type="text" name="title" value="{{ old('title', $book->title ?? '') }}" class="form-control" required>
    @error('title') <small class="text-danger">{{ $message }}</small> @enderror
</div>

<div class="mb-3">
    <label class="form-label">Author</label>
    <input type="text" name="author" value="{{ old('author', $book->author ?? '') }}" class="form-control" required>
    @error('author') <small class="text-danger">{{ $message }}</small> @enderror
</div>

<div class="mb-3">
    <label class="form-label">ISBN</label>
    <input type="text" name="isbn" value="{{ old('isbn', $book->isbn ?? '') }}" class="form-control">
</div>

<div class="mb-3">
    <label class="form-label">Published Year</label>
    <input type="text" name="published_year" value="{{ old('published_year', $book->published_year ?? '') }}" class="form-control">
</div>

<div class="mb-3">
    <label class="form-label">Borrower</label>
    <select name="borrower_id" class="form-control">
        <option value="">-- Available (no borrower) --</option>
        @foreach($members as $member)
            <option value="{{ $member->id }}" 
                {{ old('borrower_id', $book->borrower_id ?? '') == $member->id ? 'selected' : '' }}>
                {{ $member->full_name }} ({{ $member->email }})
            </option>
        @endforeach
    </select>
</div>

<button class="btn btn-success">Save</button>
<a href="{{ route('books.index') }}" class="btn btn-secondary">Cancel</a>
