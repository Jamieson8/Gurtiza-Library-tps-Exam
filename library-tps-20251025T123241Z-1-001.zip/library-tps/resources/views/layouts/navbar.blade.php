<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="{{ url('/') }}">
        Library TPS
    </a>

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="{{ route('books.index') }}">
                    <i class="fas fa-book"></i> Books
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('members.index') }}">
                    <i class="fas fa-users"></i> Members
                </a>
            </li>
        </ul>

        <!-- ✅ Quick Register Borrower button -->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="btn btn-success" href="{{ route('members.create') }}">
                    <i class="fas fa-user-plus"></i> Register Borrower
                </a>
            </li>
        </ul>
    </div>
</nav>
