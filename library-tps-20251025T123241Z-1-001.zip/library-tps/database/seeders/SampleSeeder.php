<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Member;
use App\Models\Book;

class SampleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $m1 = Member::create(['first_name'=>'Juan','last_name'=>'Dela Cruz','email'=>'juan@example.com']);
    $m2 = Member::create(['first_name'=>'Ana','last_name'=>'Santos','email'=>'ana@example.com']);

    Book::create(['title'=>'Intro to PHP','author'=>'A. Author','isbn'=>'1111','published_year'=>2018,'borrower_id'=>$m1->id]);
    Book::create(['title'=>'Laravel Up & Running','author'=>'M. Author','isbn'=>'2222','published_year'=>2020,'borrower_id'=>null]);
    }
}
