<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    use HasFactory;

    protected $fillable = ['title','author','isbn','published_year','borrower_id'];

    public function borrower()
    {
        return $this->belongsTo(Member::class, 'borrower_id');
    }

    public function books()
{
    return $this->hasMany(Book::class);
}

}
