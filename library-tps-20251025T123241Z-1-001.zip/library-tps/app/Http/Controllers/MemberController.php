<?php

namespace App\Http\Controllers;

use App\Models\Member;        // <<-- important
use Illuminate\Http\Request;

class MemberController extends Controller
{
    public function index(Request $request)
{
    $search = $request->input('search');
    $status = $request->input('status'); // filter by borrowers / non-borrowers

    $members = Member::when($search, function ($query, $search) {
            return $query->where('first_name', 'like', "%{$search}%")
                         ->orWhere('last_name', 'like', "%{$search}%")
                         ->orWhere('email', 'like', "%{$search}%");
        })
        ->when($status, function ($query, $status) {
            if ($status === 'borrowers') {
                return $query->whereHas('books'); // members with borrowed books
            }
            if ($status === 'non-borrowers') {
                return $query->whereDoesntHave('books'); // members with no borrowed books
            }
        })
        ->latest()
        ->paginate(10);

    return view('members.index', compact('members', 'search', 'status'));
}


    public function create()
    {
        return view('members.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'first_name'     => 'required|string|max:255',
            'last_name'      => 'required|string|max:255',
            'email'          => 'required|email|unique:members,email',
            'contact_number' => 'nullable|string|max:50',
        ]);

        $member = Member::create($data);

        if ($request->ajax()) {
            return response()->json($member);
        }

        return redirect()->route('members.index')->with('success','Member added.');
    }

    public function show(Member $member)
    {
        return view('members.show', compact('member'));
    }

    public function edit(Member $member)
    {
        return view('members.edit', compact('member'));
    }

    public function update(Request $request, Member $member)
    {
        $data = $request->validate([
            'first_name'     => 'required|string|max:255',
            'last_name'      => 'required|string|max:255',
            'email'          => "required|email|unique:members,email,{$member->id}",
            'contact_number' => 'nullable|string|max:50',
        ]);

        $member->update($data);
        return redirect()->route('members.index')->with('success','Member updated.');
    }

    public function destroy(Member $member)
    {
        $member->delete();
        return redirect()->route('members.index')->with('success','Member deleted.');
    }

    public function borrowedBooks(Member $member)
{
    $books = $member->books()->with('borrower')->get();
    return view('members.borrowed_books', compact('member', 'books'));
}

public function books($id)
{
    $member = Member::with('books')->findOrFail($id);
    return view('members.books', compact('member'));
}

}
