<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Member;
use Illuminate\Http\Request;

class BookController extends Controller
{
    public function index(Request $request)
{
    $search = $request->input('search');
    $status = $request->input('status'); // filter for available/borrowed

    $books = Book::with('borrower')
        ->when($search, function ($query, $search) {
            return $query->where('title', 'like', "%{$search}%")
                         ->orWhere('author', 'like', "%{$search}%");
        })
        ->when($status, function ($query, $status) {
            if ($status === 'available') {
                return $query->whereNull('borrower_id');
            }
            if ($status === 'borrowed') {
                return $query->whereNotNull('borrower_id');
            }
        })
        ->latest()
        ->paginate(10);

    return view('books.index', compact('books', 'search', 'status'));
}

    public function create()
    {
        $members = Member::all();
        return view('books.create', compact('members'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title'          => 'required|string|max:255',
            'author'         => 'required|string|max:255',
            'isbn'           => 'nullable|string|max:50',
            'published_year' => 'nullable|integer',
            'borrower_id'    => 'nullable|exists:members,id',
        ]);

        Book::create($data);
        return redirect()->route('books.index')->with('success', 'Book added.');
    }

    public function edit(Book $book)
    {
         $members = Member::all(); // so you can pick borrower
    return view('books.edit', compact('book', 'members'));
    }

    public function update(Request $request, Book $book)
    {
           $data = $request->validate([
        'title'        => 'required|string|max:255',
        'author'       => 'required|string|max:255',
        'borrower_id'  => 'nullable|exists:members,id',
    ]);

    $book->update($data);

    return redirect()->route('books.index')->with('success', 'Book updated successfully.');
    }

    public function destroy(Book $book)
    {
        $book->delete();
        return redirect()->route('books.index')->with('success', 'Book deleted.');
    }
}
