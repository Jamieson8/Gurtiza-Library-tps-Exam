

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-10">

            <div class="card shadow-sm">
                <div class="card-header bg-dark text-white text-center">
                    <h4><i class="fas fa-home"></i> Main Wall</h4>
                </div>

                <div class="card-body">
                    <p class="text-center mb-4">Welcome to the Library Transaction Processing System</p>

                    <div class="row g-4 text-center">

                        <!-- Members -->
                        <div class="col-md-3">
                            <a href="<?php echo e(route('members.index')); ?>" class="text-decoration-none">
                                <div class="card border-0 shadow-sm h-100 hover-effect">
                                    <div class="card-body">
                                        <i class="fas fa-users fa-3x text-primary mb-2"></i>
                                        <h6 class="text-dark">Members</h6>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <!-- Books -->
                        <div class="col-md-3">
                            <a href="<?php echo e(route('books.index')); ?>" class="text-decoration-none">
                                <div class="card border-0 shadow-sm h-100 hover-effect">
                                    <div class="card-body">
                                        <i class="fas fa-book fa-3x text-success mb-2"></i>
                                        <h6 class="text-dark">Books</h6>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <!-- Borrowed Books -->
                        <div class="col-md-3">
                            <a href="<?php echo e(route('members.index')); ?>?status=borrowers" class="text-decoration-none">
                                <div class="card border-0 shadow-sm h-100 hover-effect">
                                    <div class="card-body">
                                        <i class="fas fa-book-reader fa-3x text-warning mb-2"></i>
                                        <h6 class="text-dark">Borrowed</h6>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <!-- Reports -->
                        <div class="col-md-3">
                            <a href="#" class="text-decoration-none">
                                <div class="card border-0 shadow-sm h-100 hover-effect">
                                    <div class="card-body">
                                        <i class="fas fa-chart-bar fa-3x text-danger mb-2"></i>
                                        <h6 class="text-dark">Reports</h6>
                                    </div>
                                </div>
                            </a>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Hover effect -->
<style>
    .hover-effect:hover {
        transform: scale(1.05);
        transition: 0.3s;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\library-tps\resources\views/dashboard.blade.php ENDPATH**/ ?>