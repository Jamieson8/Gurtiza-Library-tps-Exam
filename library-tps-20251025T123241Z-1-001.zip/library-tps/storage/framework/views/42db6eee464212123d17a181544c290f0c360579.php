

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card shadow-sm">
                <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                    <h4 class="mb-0"><i class="fas fa-book"></i> Books List</h4>
                    <div>
                        <!-- Back to Main Wall -->
                        <a href="<?php echo e(url('/')); ?>" class="btn btn-secondary me-2">
                            <i class="fas fa-arrow-left"></i> Back to Main
                        </a>
                        <!-- Add Book -->
                        <a href="<?php echo e(route('books.create')); ?>" class="btn btn-success">
                            <i class="fas fa-plus"></i> Add Book
                        </a>
                    </div>
                </div>

                <div class="card-body">
                    <!-- Search & Filter -->
                    <form method="GET" action="<?php echo e(route('books.index')); ?>" class="row g-2 mb-3">
                        <div class="col-md-4">
                            <input type="text" name="search" class="form-control"
                                   placeholder="Search by title or author"
                                   value="<?php echo e($search ?? ''); ?>">
                        </div>
                        <div class="col-md-5 d-flex">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-search"></i> Search
                            </button>
                            <a href="<?php echo e(route('books.index')); ?>" class="btn btn-secondary">
                                <i class="fas fa-sync"></i> Reset
                            </a>
                        </div>
                    </form>

                    <!-- Table -->
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead class="table-dark">
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Author</th>
                                    <th>Status</th>
                                    <th>Borrower</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($book->id); ?></td>
                                        <td><?php echo e($book->title); ?></td>
                                        <td><?php echo e($book->author); ?></td>
                                        <td>
                                            <?php if($book->borrower_id): ?>
                                                <span class="badge bg-warning">Borrowed</span>
                                            <?php else: ?>
                                                <span class="badge bg-success">Available</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($book->borrower): ?>
                                                <?php echo e($book->borrower->first_name); ?> <?php echo e($book->borrower->last_name); ?>

                                            <?php else: ?>
                                                <span class="text-muted">None</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('books.edit', $book->id)); ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                            <form action="<?php echo e(route('books.destroy', $book->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted">No books found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="mt-3">
                        <?php echo e($books->appends(['search' => $search])->links()); ?>

                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\library-tps\resources\views/books/index.blade.php ENDPATH**/ ?>