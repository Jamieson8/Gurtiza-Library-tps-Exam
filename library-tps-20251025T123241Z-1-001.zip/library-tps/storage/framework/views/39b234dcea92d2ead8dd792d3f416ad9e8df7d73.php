

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card shadow-sm">
                <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <!-- Back to Main Wall Button -->
                        <a href="<?php echo e(url('/')); ?>" class="btn btn-outline-light me-3">
                            <i class="fas fa-arrow-left"></i> Back to Main
                        </a>
                        <h4 class="mb-0"><i class="fas fa-users"></i> Members List</h4>
                    </div>
                    <a href="<?php echo e(route('members.create')); ?>" class="btn btn-success">
                        <i class="fas fa-user-plus"></i> Add Member
                    </a>
                </div>

                <div class="card-body">
                    <!-- Search & Filter -->
                    <form method="GET" action="<?php echo e(route('members.index')); ?>" class="row g-2 mb-3">
                        <div class="col-md-4">
                            <input type="text" name="search" class="form-control"
                                   placeholder="Search by name or email"
                                   value="<?php echo e($search ?? ''); ?>">
                        </div>
                        <div class="col-md-3">
                            <select name="status" class="form-select">
                                <option value="">-- All Members --</option>
                                <option value="borrowers" <?php echo e($status == 'borrowers' ? 'selected' : ''); ?>>Borrowers</option>
                                <option value="non-borrowers" <?php echo e($status == 'non-borrowers' ? 'selected' : ''); ?>>Non-Borrowers</option>
                            </select>
                        </div>
                        <div class="col-md-5 d-flex">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-search"></i> Search
                            </button>
                            <a href="<?php echo e(route('members.index')); ?>" class="btn btn-secondary">
                                <i class="fas fa-sync"></i> Reset
                            </a>
                        </div>
                    </form>

                    <!-- Table -->
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead class="table-dark">
                                <tr>
                                    <th>#</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Contact Number</th>
                                    <th>Borrowed Books</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($member->id); ?></td>
                                        <td><?php echo e($member->first_name); ?></td>
                                        <td><?php echo e($member->last_name); ?></td>
                                        <td><?php echo e($member->email); ?></td>
                                        <td><?php echo e($member->contact_number); ?></td>
                                        <td>
                                            <?php if($member->books->count() > 0): ?>
                                                <a href="<?php echo e(route('members.books', $member->id)); ?>" class="badge bg-info text-decoration-none">
                                                    <?php echo e($member->books->count()); ?> borrowed
                                                </a>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">None</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('members.edit', $member->id)); ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                            <form action="<?php echo e(route('members.destroy', $member->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted">No members found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="mt-3">
                        <?php echo e($members->appends(['search' => $search, 'status' => $status])->links()); ?>

                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\library-tps\resources\views/members/index.blade.php ENDPATH**/ ?>